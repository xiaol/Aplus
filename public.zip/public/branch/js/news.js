$(function() {
	var p = news.compute('蔡依林做手表蛋糕让妈妈');
    var div = document.getElementById("test");
    // alert(($("#test").width()));
    // console.log($("#test").height());
    // alert(p.w + '\n' + p.h);
});